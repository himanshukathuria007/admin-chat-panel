module.exports = {
    'secretToken': 'TestProjectDemo',
    'jwt': require('jsonwebtoken'),
    'md5': require('md5')
}